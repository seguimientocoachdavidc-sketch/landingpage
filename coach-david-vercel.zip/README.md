# Coach David — Static Landing Page

Pure HTML/CSS/JS export. No build step required.

## Structure
```
.
├── index.html          # Full landing page (Tailwind CDN + inline JS)
├── assets/             # Images (logo, hero, coach photo)
├── vercel.json         # Vercel hosting config
└── README.md
```

## Deploy on Vercel

### Option A — Vercel CLI
```bash
npm i -g vercel
vercel
```
Accept defaults. The site is fully static; no framework preset needed.

### Option B — GitHub + Vercel dashboard
1. Push this folder to a GitHub repository.
2. Go to https://vercel.com/new and import the repo.
3. Framework preset: **Other**. Build command: *(leave empty)*. Output directory: `./`.
4. Click **Deploy**.

### Option C — Drag & drop
Zip the folder and drag it into https://vercel.com/new.

## Local preview
Just open `index.html` in a browser, or:
```bash
npx serve .
```

## Notes
- Tailwind is loaded via CDN for simplicity. For production you may want to compile Tailwind to a static CSS file (`npx tailwindcss -o styles.css --minify`) and remove the CDN script.
- Replace the WhatsApp number `0000000000` in `index.html` with your real number.
- The contact form currently shows a toast only — wire it up to Formspree, Resend, or your own endpoint to receive submissions.
